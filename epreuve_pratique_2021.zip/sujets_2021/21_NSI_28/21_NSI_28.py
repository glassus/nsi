def tri_iteratif(tab):
    for k in range( ... , 0, -1):
        imax = ...
        for i in range(0 , ... ):
            if tab[i] > ... :
                imax = i
        if tab[max] > ... :
            ... , tab[imax] = tab[imax] , ...
    return tab
